# NitroPerks
 Unlock all screensharing modes, and use cross-server emotes & gif emotes, Discord wide! (Reactions broken.)
